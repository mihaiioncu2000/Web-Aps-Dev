package daw.beans;

import java.util.Date;

public class TestBean {
	private String message = "No message specified";

	private Date postdate;
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
